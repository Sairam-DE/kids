from django.contrib import admin
from uploader.models import ImageFile


admin.site.register(ImageFile)
